import os
import pandas as pd
import calendar
from datetime import datetime


def third_friday(year, month):

        c = calendar.Calendar(firstweekday=calendar.MONDAY)
        monthcal = c.monthdatescalendar(year,month)
        friday3 = [day for week in monthcal for day in week if \
                day.weekday() == calendar.FRIDAY and \
                day.month == month][2]
        return friday3


def get_buckets(variable, buckets_df):

        return [row['O_COORDINATE'] for _, row in buckets_df.iterrows() if row['O_MIN'] <= variable < row['O_MAX']]



if __name__ == '__main__':

    working_path = os.getcwd()

    MEFF_Op_df = pd.read_csv(working_path + r'/20230208_20230130_CCONTRACTS_Trades_o_OpenI.csv',
                         sep=';', decimal = ',')
    TradTable_df = pd.read_excel(working_path + r'/20230207_StaticTable_v2.xlsx', sheet_name='Stock')
    TradTable_df = TradTable_df[TradTable_df['M_VENDOR'] == 'MEFF']

    DateTable_df = pd.read_excel(working_path + r'/20230207_StaticTable_v2.xlsx', sheet_name='Date')
    DateTable_dict = dict(zip(DateTable_df['Char Value'], list(range(1,13))))

    Mapeo_df = pd.read_csv(working_path + r'/Mapeo.csv', sep = ';', decimal = ',')

    split = MEFF_Op_df['ContractCode'].str.split(expand = True)
    MEFF_Op_df[['RefUnderlying', 'Ref']] = split
    MEFF_Op_df = MEFF_Op_df.dropna(subset=['Ref'])
    MEFF_Op_df['RefUnderlying'] = MEFF_Op_df['RefUnderlying'].str[1:].replace('AM$|EU$', '', regex=True)
    MEFF_Op_df['Strike'] = MEFF_Op_df['Ref'].str.findall('^[0-9]+')
    MEFF_Op_df['Strike'] = MEFF_Op_df['Strike'].explode()
    MEFF_Op_df['Year'] = MEFF_Op_df['Ref'].str[-2:].apply(pd.to_numeric, errors='coerce')
    MEFF_Op_df['Month'] = MEFF_Op_df['Ref'].str[-3]
    MEFF_Op_df['Month'] = MEFF_Op_df['Month'].map(DateTable_dict)
    MEFF_Op_df = MEFF_Op_df.dropna(subset=['Year','Month'])
    MEFF_Op_df['Year'] = 2000 + MEFF_Op_df['Year']
    MEFF_Op_df = MEFF_Op_df.astype({'Year': 'int32', 'Month': 'int32'})
    MEFF_Op_df['Date'] = MEFF_Op_df.apply(lambda row: third_friday(row['Year'], row['Month']), axis=1)
    MEFF_Op_df['TradeDate'] = MEFF_Op_df.apply(lambda row: datetime.strptime(str(row['SessionDate']), '%Y%m%d').date(), axis=1)
    MEFF_Op_df['NumOfDays'] = MEFF_Op_df['Date']-MEFF_Op_df['TradeDate']
    MEFF_Op_df['Tenor'] = MEFF_Op_df.apply(lambda row: get_buckets(row['NumOfDays'], Mapeo_df), axis=1)



a = 0